
  ██████  ██  ██████   ██████  ██      ███████     ████████ ███████  ██████ ██   ██
 ██       ██ ██       ██       ██      ██             ██    ██      ██      ██   ██
 ██   ███ ██ ██   ███ ██   ███ ██      █████          ██    █████   ██      ███████ 
 ██    ██ ██ ██    ██ ██    ██ ██      ██             ██    ██      ██      ██   ██ 
  ██████  ██  ██████   ██████  ███████ ███████        ██    ███████  ██████ ██   ██

Just a few steps, you are almost ready to go!
  
>>> LED Indicator 
 
The indication LED is located next to the USB port. It will give you feedback to what your device is doing.
	
	Power Up: The LED will blink 4x when the device is first connected to power.
	Configuration Mode: The LED will light a solid colour 
	Device Ready: The LED will blink 3x times, and the motor will pulse 3x times after 'Power Up'	[10-15s after powerup]
	
>>> Configuration Mode

The device will enter configuation mode if the device can not connect to a WIFI network.
	
Entering Configuration Mode: 
	1: Power up the device. Wait 3secs
	2: Unplug and replug the device.
	3: The device will now be in configuation mode, shown by the LED.
	
Exiting Configuration Mode:
	Option 1: Power cycle the deivce
	Option 2: Exit via the web page [Exit Portal Button]
	Option 3: Wait for timeout of 5mins [If the deivce has WIFI credintals saved]

>>> Device & Router Setup
 
Step 1: Connect Headpat IO Deivce to your wifi

	- Power up your Headpat Device, it should now be in the "Configuration Mode" [as it has not connected to your WIFI before]
	- Use your phone/pc WIFI to connect to the device  
		SSID: GiggleTech_Haptics 
		Password: giggletech
	- Sign into the device via you phone, or http://192.168.4.1
	- Enter your WIFI credintials via the configuation page
		note: if you leave the IP details blank, your router will auto-assing an IP if avaible.
	- Save and exit the portal/configuation mode
			
Step 2: Configure the OSC Router
	
	- With the device powered on, it should now be in the "Device Ready" state
	- On your PC, navigate to http://giggletech.local/
	- Copy the IP address
	- Open the 'config.ini' file 
	- Paste the IP address:  Headpat_IO_IP = "YOUR IP ADDRESS HERE", example Headpat_IO_IP = 192.168.1.155
	- Save and close config.ini

Step 3: Confirm device operation
	
	- With the device powered on, it should now be in the "Device Ready" state
	- Open 'GiggleTech_OSC_Router.exe'
	- Open 'Headpat_Simulator.exe'
	- Follow the prompts in 'Headpat_Simulator.exe'| it will now run through tests to make sure you device is working correctly
	
If your device responds to the 'Headpat_Simulator.exe' tests, your device is ready to go


>>> Router Config.ini

# Port listening for OSC [Default 9001]	
  port_rx = 9001

If you have other OSC application, you can change the port giggletech osc router recives its messages from.
OSC Fowarding is planned for future updates	

# Min Speed of Haptic Motor [5-100]
  min_speed = 2

This will set the lower speed the haptic drive runs at. This is to prevent stalling.

# Max Speed of Haptic Motor [Recommend 10-25]			
  max_speed = 12

Max speed is where you can tune your haptic experiance.
This parameters can be tunned from within VRChat if you have setup your quick menu.
If not, it will default to this value.

For a 

# Max Speed Scalar [10-100]
  max_speed_scale = 100

This will scale your in-game max speed setting parameter, for fine tunning.

Enjoy!



	